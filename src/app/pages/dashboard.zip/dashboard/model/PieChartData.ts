export interface PieChartData {
  pos: number;
  name: string;
  description: string;
  value: number;
}
