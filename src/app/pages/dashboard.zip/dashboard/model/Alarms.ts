export interface Alarms {
  
  idValueAlarm: string;
    date: string;
    time: string;
    alarmType:string;
    username:string;
    alias:string;
    phone:string;
    position:string;
    accuracy:string;
    isRealAlarm:boolean;
   
  }
  