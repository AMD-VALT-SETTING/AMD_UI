import { User } from 'app/model/User';


export class DashboardEvent {
    constructor(public dashboardEvent:User[]) {
        }
    
}